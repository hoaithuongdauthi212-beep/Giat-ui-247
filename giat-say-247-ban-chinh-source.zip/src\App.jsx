﻿import React, { useEffect, useMemo, useState } from 'react';
import { AlertCircle, CheckCircle, Clock, Database, DollarSign, KeyRound, LogIn, LogOut, Package, PlusCircle, Printer, RefreshCw, Search, Settings, ShieldCheck, Shirt, TrendingUp, User, UserPlus, Users, X, Pencil, Trash2 } from 'lucide-react';

const DEFAULT_SERVICES = [
  { id: 'srv_1', name: 'Giặt sấy quần áo', unit: 'Kg', price: 12000, desc: 'Tính theo khối lượng (Kg)' },
  { id: 'srv_2', name: 'Giặt sấy chăn gối mền', unit: 'Kg', price: 18000, desc: 'Tính theo khối lượng (Kg)' },
  { id: 'srv_3', name: 'Giặt gấu bông', unit: 'Kg', price: 25000, desc: 'Tính theo khối lượng (Kg)' },
  { id: 'srv_4', name: 'Vệ sinh giày', unit: 'Đôi', price: 35000, desc: 'Tính theo số lượng (Đôi)' },
  { id: 'srv_5', name: 'Giặt ủi', unit: 'Cái', price: 10000, desc: 'Tính theo số lượng (Cái)' }
];
const USERS = [
  { id: 'usr_1', username: 'admin', password: '123', name: 'Quản Lý Tiệm', role: 'owner' },
  { id: 'usr_2', username: 'nhanvien', password: '456', name: 'Nhân Viên Tiệm', role: 'employee' }
];
const CUSTOMERS = [
  { id: 'cust_1', customerCode: 'KH-0001', name: 'Nguyễn Văn Minh', phone: '0905123456', totalOrders: 4 },
  { id: 'cust_2', customerCode: 'KH-0002', name: 'Lê Thị Thu Hà', phone: '0988765432', totalOrders: 2 }
];
const ORDERS = [
  { id: 'GS-1001', customerId: 'cust_1', customerName: 'Nguyễn Văn Minh', phone: '0905123456', serviceName: 'Giặt sấy quần áo', quantity: 5, unit: 'Kg', unitPrice: 12000, totalAmount: 60000, paymentTiming: 'tra_truoc', paymentMethod: 'tien_mat', paymentStatus: 'da_thanh_toan', status: 'da_hoan_thanh', createdAt: '30/10/2026 08:30', notes: 'Khách dặn sấy thơm', employeeName: 'Nhân Viên Tiệm', actualProcessingMinutes: 1440 },
  { id: 'GS-1002', customerId: 'cust_2', customerName: 'Lê Thị Thu Hà', phone: '0988765432', serviceName: 'Vệ sinh giày', quantity: 2, unit: 'Đôi', unitPrice: 35000, totalAmount: 70000, paymentTiming: 'tra_sau', paymentMethod: 'chua_chon', paymentStatus: 'chua_thanh_toan', status: 'dang_xu_ly', createdAt: '31/10/2026 10:15', notes: 'Giày thể thao trắng', employeeName: 'Nhân Viên Tiệm' }
];
const read = (key, fallback) => JSON.parse(localStorage.getItem(key) || 'null') || fallback;
const money = value => `${Number(value || 0).toLocaleString('vi-VN')} đ`;
const labels = { dang_xu_ly: 'Đang xử lý', da_xu_ly: 'Đã xử lý', da_hoan_thanh: 'Đã hoàn thành' };
const isValidPhone = value => /^0[35789]\d{8}$/.test(value);
const formatDateTime = value => {
  if (!value) return 'Chưa nhập';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }).replace(',', '');
};
const getOrderServices = order => order.services?.length ? order.services : [{ name: order.serviceName, quantity: order.quantity, unit: order.unit, unitPrice: order.unitPrice, total: order.totalAmount }];
const nextCustomerCode = customers => `KH-${String(customers.reduce((max, item) => Math.max(max, Number(String(item.customerCode || '').replace(/\D/g, '')) || 0), 0) + 1).padStart(4, '0')}`;
const serviceSelection = services => Object.fromEntries(services.map(service => [service.id, { selected: false, quantity: 1 }]));
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const remoteEnabled = Boolean(supabaseUrl && supabaseKey);
const DEFAULT_SYSTEM_SETTINGS = { processingLimitHours: 24 };
async function syncSupabase(table, row) {
  if (!remoteEnabled) return;
  const response = await fetch(`${supabaseUrl}/rest/v1/${table}?on_conflict=id`, {
    method: 'POST',
    headers: { apikey: supabaseKey, Authorization: `Bearer ${supabaseKey}`, 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates' },
    body: JSON.stringify(row)
  });
  if (!response.ok) console.warn(`Supabase không lưu được bảng ${table}:`, await response.text());
}

export default function App() {
  const [services, setServices] = useState(() => read('gs_services', DEFAULT_SERVICES));
  const [users, setUsers] = useState(() => [...USERS, ...read('gs_users', []).filter(item => !USERS.some(user => user.username === item.username))]);
  const [customers, setCustomers] = useState(() => read('gs_customers', CUSTOMERS));
  const [orders, setOrders] = useState(() => read('gs_orders', ORDERS));
  const [currentUser, setCurrentUser] = useState(null);
  const [tab, setTab] = useState('revenue');
  const [authMode, setAuthMode] = useState('login');
  const [auth, setAuth] = useState({ username: '', password: '', role: 'owner' });
  const [authError, setAuthError] = useState('');
  const [form, setForm] = useState({ name: '', phone: '', services: serviceSelection(services), paymentTiming: 'tra_truoc', paymentMethod: 'tien_mat', estimatedReturnAt: '', notes: '' });
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [orderQuery, setOrderQuery] = useState('');
  const [orderFilter, setOrderFilter] = useState('all');
  const [customerQuery, setCustomerQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [customerEdit, setCustomerEdit] = useState(null);
  const [paymentOrder, setPaymentOrder] = useState(null);
  const [payMethod, setPayMethod] = useState('tien_mat');
  const [passwords, setPasswords] = useState({ old: '', next: '', confirm: '' });
  const [settingsMessage, setSettingsMessage] = useState(null);
  const [systemSettings, setSystemSettings] = useState(() => {
    const saved = read('gs_system_settings', {});
    if (Number.isFinite(Number(saved.processingLimitHours))) return { processingLimitHours: Number(saved.processingLimitHours) };
    if (Number.isFinite(Number(saved.processingLimitMinutes))) return { processingLimitHours: Number(saved.processingLimitMinutes) / 60 };
    return DEFAULT_SYSTEM_SETTINGS;
  });

  useEffect(() => localStorage.setItem('gs_services', JSON.stringify(services)), [services]);
  useEffect(() => localStorage.setItem('gs_users', JSON.stringify(users)), [users]);
  useEffect(() => localStorage.setItem('gs_customers', JSON.stringify(customers)), [customers]);
  useEffect(() => localStorage.setItem('gs_orders', JSON.stringify(orders)), [orders]);
  useEffect(() => localStorage.removeItem('gs_current_user'), [currentUser]);
  useEffect(() => localStorage.setItem('gs_system_settings', JSON.stringify(systemSettings)), [systemSettings]);
  useEffect(() => { if (!remoteEnabled) return; Promise.all(['services', 'customers', 'orders'].map(table => fetch(`${supabaseUrl}/rest/v1/${table}?select=*`, { headers: { apikey: supabaseKey, Authorization: `Bearer ${supabaseKey}` } }).then(response => response.ok ? response.json() : []))).then(([remoteServices, remoteCustomers, remoteOrders]) => { if (remoteServices.length) setServices(remoteServices); if (remoteCustomers.length) setCustomers(remoteCustomers); if (remoteOrders.length) setOrders(remoteOrders); }).catch(error => console.warn('Không tải được dữ liệu Supabase:', error)); }, []);

  const revenue = orders.reduce((sum, item) => sum + (item.paymentStatus === 'da_thanh_toan' ? item.totalAmount : 0), 0);
  const waitingRevenue = orders.reduce((sum, item) => sum + (item.paymentStatus === 'chua_thanh_toan' ? item.totalAmount : 0), 0);
  const overdueOrders = orders.filter(order => { const startedAt = new Date(order.createdAtISO || order.createdAt).getTime(); return order.status !== 'da_hoan_thanh' && Number.isFinite(startedAt) && Date.now() - startedAt >= Number(systemSettings.processingLimitHours || DEFAULT_SYSTEM_SETTINGS.processingLimitHours) * 3600000; });
  const filteredOrders = orders.filter(item => {
    const matchesQuery = `${item.id} ${item.customerName} ${item.phone}`.toLowerCase().includes(orderQuery.toLowerCase());
    const isOverdue = overdueOrders.some(order => order.id === item.id);
    return matchesQuery && (orderFilter === 'all' || orderFilter === 'overdue' ? orderFilter === 'all' || isOverdue : item.status === orderFilter);
  });
  const filteredCustomers = customers.filter(item => `${item.customerCode} ${item.name} ${item.phone}`.toLowerCase().includes(customerQuery.toLowerCase()));
  const setField = (key, value) => setForm(prev => ({ ...prev, [key]: value }));
  const persist = (table, row) => syncSupabase(table, row).catch(error => console.warn('Lỗi đồng bộ Supabase:', error));
  const saveSystemSettings = nextSettings => {
    const limit = Number(nextSettings.processingLimitHours);
    if (!Number.isFinite(limit) || limit < 1) return setSettingsMessage({ error: 'Ngưỡng thời gian phải là số giờ lớn hơn 0.' });
    setSystemSettings({ processingLimitHours: limit });
    setSettingsMessage({ success: 'Đã lưu ngưỡng thời gian.' });
  };

  const handleAuth = event => {
    event.preventDefault();
    const username = auth.username.trim();
    if (authMode === 'login') {
      const user = users.find(item => item.username === username && item.password === auth.password && item.role === auth.role);
      if (!user) return setAuthError('Tên đăng nhập, mật khẩu hoặc vai trò không đúng!');
      setCurrentUser(user);
    } else {
      if (!username || !auth.password) return setAuthError('Vui lòng nhập đầy đủ thông tin!');
      if (users.some(item => item.username === username)) return setAuthError('Tên đăng nhập đã tồn tại!');
      const user = { id: `usr_${Date.now()}`, username, password: auth.password, name: username, role: 'employee' };
      setUsers([...users, user]); setCurrentUser(user);
    }
    setAuth({ username: '', password: '', role: 'owner' }); setAuthError('');
  };
  const searchCustomers = () => {
    const query = search.trim().toLowerCase();
    if (!query) return alert('Vui lòng nhập mã, tên hoặc số điện thoại khách hàng!');
    setSearchResults(customers.filter(item => `${item.customerCode} ${item.name} ${item.phone}`.toLowerCase().includes(query)));
  };
  const suggestReturn = selectedServices => {
    const history = orders.filter(order => order.status === 'da_hoan_thanh' && order.actualProcessingMinutes && getOrderServices(order).some(item => selectedServices.some(service => service.name === item.name)));
    if (history.length < 10) return { text: '24 giờ (mặc định, chưa đủ 10 đơn lịch sử)', value: new Date(Date.now() + 24 * 3600000).toISOString().slice(0, 16) };
    const average = Math.round(history.reduce((sum, item) => sum + item.actualProcessingMinutes, 0) / history.length);
    return { text: `${Math.ceil(average / 60)} giờ (học từ ${history.length} đơn)`, value: new Date(Date.now() + average * 60000).toISOString().slice(0, 16) };
  };
  const selectedForSuggestion = services.filter(service => form.services[service.id]?.selected).map(service => ({ name: service.name }));
  const learningSuggestion = suggestReturn(selectedForSuggestion);
  const createOrder = event => {
    event.preventDefault();
    const selectedServices = services.filter(service => form.services[service.id]?.selected).map(service => { const quantity = Number(form.services[service.id].quantity); const unitPrice = Number(service.price); return { name: service.name, quantity, unit: service.unit, unitPrice, total: unitPrice * quantity }; });
    if (!form.name.trim() || !isValidPhone(form.phone.trim())) return alert('Số điện thoại phải là số di động Việt Nam gồm 10 chữ số và bắt đầu bằng 0!');
    if (!selectedServices.length) return alert('Vui lòng tích chọn ít nhất một dịch vụ!');
    if (selectedServices.some(item => !Number.isFinite(item.quantity) || item.quantity <= 0 || (item.unit !== 'Kg' && !Number.isInteger(item.quantity)))) return alert('Số lượng không hợp lệ!');
    if (form.estimatedReturnAt && new Date(form.estimatedReturnAt).getTime() <= Date.now()) return alert('Thời gian trả dự kiến phải ở tương lai!');
    const existing = customers.find(item => item.phone === form.phone.trim());
    const customerId = existing?.id || `cust_${Date.now()}`;
    const updatedCustomer = existing ? { ...existing, name: form.name.trim(), totalOrders: existing.totalOrders + 1 } : { id: customerId, customerCode: nextCustomerCode(customers), name: form.name.trim(), phone: form.phone.trim(), totalOrders: 1 };
    const suggestion = suggestReturn(selectedServices);
    const paid = form.paymentTiming === 'tra_truoc';
    const order = { id: `GS-${Math.floor(1000 + Math.random() * 9000)}`, customerId, customerCode: updatedCustomer.customerCode, customerName: form.name.trim(), phone: form.phone.trim(), services: selectedServices, serviceName: selectedServices.map(item => item.name).join(', '), quantity: selectedServices[0].quantity, unit: selectedServices[0].unit, unitPrice: selectedServices[0].unitPrice, totalAmount: selectedServices.reduce((sum, item) => sum + item.total, 0), paymentTiming: form.paymentTiming, paymentMethod: paid ? form.paymentMethod : 'chua_chon', paymentStatus: paid ? 'da_thanh_toan' : 'chua_thanh_toan', status: 'dang_xu_ly', createdAt: new Date().toLocaleString('vi-VN'), createdAtISO: new Date().toISOString(), estimatedReturnAt: form.estimatedReturnAt || suggestion.value, suggestionText: suggestion.text, employeeName: currentUser.name, notes: form.notes };
    setCustomers(existing ? customers.map(item => item.id === customerId ? updatedCustomer : item) : [...customers, updatedCustomer]); setOrders([order, ...orders]); persist('customers', updatedCustomer); persist('orders', order);
    setForm({ name: '', phone: '', services: serviceSelection(services), paymentTiming: 'tra_truoc', paymentMethod: 'tien_mat', estimatedReturnAt: '', notes: '' }); setSearchResults(null); setSearch(''); setSelected(order); setTab('orders');
  };
  const updateStatus = (id, status) => {
    const order = orders.find(item => item.id === id);
    if (status === 'da_hoan_thanh' && order.paymentStatus === 'chua_thanh_toan') { setPaymentOrder(order); setPayMethod('tien_mat'); return; }
    const updated = { ...order, status, actualProcessingMinutes: status === 'da_hoan_thanh' ? Math.max(1, Math.round((Date.now() - new Date(order.createdAtISO || order.createdAt).getTime()) / 60000)) : order.actualProcessingMinutes };
    setOrders(orders.map(item => item.id === id ? updated : item)); setSelected(updated); persist('orders', updated);
  };
  const confirmPayment = () => { const updated = { ...paymentOrder, paymentMethod: payMethod, paymentStatus: 'da_thanh_toan', status: 'da_hoan_thanh', actualProcessingMinutes: Math.max(1, Math.round((Date.now() - new Date(paymentOrder.createdAtISO || paymentOrder.createdAt).getTime()) / 60000)) }; setOrders(orders.map(item => item.id === paymentOrder.id ? updated : item)); setSelected(updated); setPaymentOrder(null); persist('orders', updated); };
  const saveCustomer = customer => { if (!customer.name.trim() || !isValidPhone(customer.phone.trim())) return alert('Số điện thoại phải là số di động Việt Nam gồm 10 chữ số và bắt đầu bằng 0!'); const updated = { ...customer, name: customer.name.trim(), phone: customer.phone.trim() }; setCustomers(customers.map(item => item.id === customer.id ? updated : item)); setOrders(orders.map(order => order.customerId === customer.id ? { ...order, customerName: updated.name, phone: updated.phone } : order)); persist('customers', updated); setCustomerEdit(null); };
  const deleteCustomer = customer => { if (!window.confirm(`Xóa khách hàng ${customer.name}? Lịch sử đơn hàng vẫn được giữ lại.`)) return; setCustomers(customers.filter(item => item.id !== customer.id)); setCustomerEdit(null); };
  const changePassword = event => { event.preventDefault(); if (passwords.old !== currentUser.password) return setSettingsMessage({ error: 'Mật khẩu cũ không đúng!' }); if (passwords.next.length < 3 || passwords.next !== passwords.confirm) return setSettingsMessage({ error: 'Mật khẩu mới không hợp lệ hoặc không khớp!' }); const updated = users.map(item => item.id === currentUser.id ? { ...item, password: passwords.next } : item); setUsers(updated); setCurrentUser({ ...currentUser, password: passwords.next }); setPasswords({ old: '', next: '', confirm: '' }); setSettingsMessage({ success: 'Đổi mật khẩu thành công!' }); };
  const changeName = name => { const trimmedName = name.trim(); if (!trimmedName) return setSettingsMessage({ error: 'Tên không được để trống!' }); const updated = users.map(item => item.id === currentUser.id ? { ...item, name: trimmedName } : item); setUsers(updated); setCurrentUser({ ...currentUser, name: trimmedName }); setSettingsMessage({ success: 'Đổi tên thành công!' }); };

  if (!currentUser) return <AuthScreen mode={authMode} setMode={mode => { setAuthMode(mode); setAuthError(''); }} auth={auth} setAuth={setAuth} error={authError} onSubmit={handleAuth} />;
  return <div className="site"><Header user={currentUser} logout={() => setCurrentUser(null)} setTab={setTab} /><Nav tab={tab} setTab={setTab} /><main className="content">
    {overdueOrders.length > 0 && <div className="overdue-banner"><AlertCircle size={18} /><div><b>Cảnh báo {overdueOrders.length} đơn quá thời gian</b><span>Đơn chưa hoàn thành đã vượt ngưỡng {systemSettings.processingLimitHours} giờ.</span></div><button className="red-button" onClick={() => { setOrderFilter('overdue'); setTab('orders'); }}>Xem đơn quá hạn</button></div>}
    {tab === 'revenue' && <Revenue orders={orders} revenue={revenue} waiting={waitingRevenue} services={services} setServices={setServices} canEdit={currentUser.role === 'owner'} />}
    {tab === 'create_order' && <CreateOrder form={form} setField={setField} search={search} setSearch={setSearch} results={searchResults} searchCustomers={searchCustomers} onSubmit={createOrder} services={services} learningSuggestion={learningSuggestion} />}
    {tab === 'orders' && <Orders orders={filteredOrders} query={orderQuery} setQuery={setOrderQuery} filter={orderFilter} setFilter={setOrderFilter} selected={selected} setSelected={setSelected} updateStatus={updateStatus} />}
    {tab === 'customers' && <Customers customers={filteredCustomers} query={customerQuery} setQuery={setCustomerQuery} onEdit={setCustomerEdit} onDelete={deleteCustomer} />}
    {tab === 'erd' && <ERDDiagram />}
    {tab === 'permissions' && <PermissionsPage />}
    {tab === 'settings' && <SettingsPage user={currentUser} passwords={passwords} setPasswords={setPasswords} message={settingsMessage} onSubmit={changePassword} onNameChange={changeName} systemSettings={systemSettings} onSaveSystemSettings={saveSystemSettings} />}
  </main>{paymentOrder && <PaymentModal order={paymentOrder} method={payMethod} setMethod={setPayMethod} cancel={() => setPaymentOrder(null)} confirm={confirmPayment} />}{customerEdit && <CustomerModal customer={customerEdit} onSave={saveCustomer} onDelete={deleteCustomer} onClose={() => setCustomerEdit(null)} />}</div>;
}

function AuthScreen({ mode, setMode, auth, setAuth, error, onSubmit }) { return <div className="auth-page"><form className="auth-box" onSubmit={onSubmit}><img className="auth-logo" src="/logo-icon.png" alt="Giặt Sấy 247" /><h1>Giặt Sấy 247</h1><p>Đăng nhập vào hệ thống</p><div className="role-choice"><button type="button" className={auth.role === 'owner' ? 'chosen' : ''} onClick={() => setAuth({ ...auth, role: 'owner' })}>Chủ tiệm</button><button type="button" className={auth.role === 'employee' ? 'chosen' : ''} onClick={() => setAuth({ ...auth, role: 'employee' })}>Nhân viên</button></div>{error && <div className="error"><AlertCircle size={15} />{error}</div>}<label><User size={15} />Tên đăng nhập<input required value={auth.username} onChange={event => setAuth({ ...auth, username: event.target.value })} /></label><label><KeyRound size={15} />Mật khẩu<input required type="password" value={auth.password} onChange={event => setAuth({ ...auth, password: event.target.value })} /></label><button className="blue-button full" type="submit">{mode === 'login' ? <LogIn size={16} /> : <UserPlus size={16} />}{mode === 'login' ? 'Đăng nhập' : 'Đăng ký'}</button><div className="auth-toggle"><button type="button" className={mode === 'login' ? 'selected' : ''} onClick={() => setMode('login')}>Đăng nhập</button><button type="button" className={mode === 'register' ? 'selected' : ''} onClick={() => setMode('register')}>Đăng ký</button></div><small>Tài khoản demo: <b>{auth.role === 'owner' ? 'admin / 123' : 'nhanvien / 456'}</b></small></form></div>; }
function Header({ user, logout, setTab }) { return <header className="site-header"><div className="brand" onClick={() => setTab('revenue')}><img src="/logo-icon.png" alt="Giặt Sấy 247" /><div><b>Giặt Sấy 247</b><small>Quản lý quy trình & đơn hàng</small></div></div><div className="header-user">{user.name}<small className="role-badge">{user.role === 'owner' ? 'Chủ' : 'Nhân viên'}</small><button onClick={logout} title="Đăng xuất"><LogOut size={18} /></button></div></header>; }
function Nav({ tab, setTab }) { return <nav className="tabs">{[['revenue', 'Báo cáo doanh thu', TrendingUp], ['create_order', 'Tạo đơn mới', PlusCircle], ['orders', 'Quản lý đơn hàng', Package], ['customers', 'Khách hàng', Users], ['erd', 'Sơ đồ ERD', Database], ['permissions', 'Màn hình & phân quyền', ShieldCheck], ['settings', 'Cài đặt', Settings]].map(([id, label, Icon]) => <button className={tab === id ? 'active' : ''} onClick={() => setTab(id)} key={id}><Icon size={16} />{label}</button>)}</nav>; }
function ERDDiagram() {
  return <section className="stack erd-page">
    <div className="erd-title-row"><div><h2>Sơ đồ quan hệ thực thể</h2><p>Các bảng và mối quan hệ trong cơ sở dữ liệu Giặt Sấy 247.</p></div><a className="erd-public-link" href="/erd.html" target="_blank" rel="noreferrer">Mở link công khai ↗</a></div>
    <iframe className="erd-frame" title="Sơ đồ quan hệ thực thể Giặt Sấy 247" src="/erd.html?embed=1" />
  </section>;
}
function PermissionsPage() {
  return <section className="stack erd-page">
    <div className="erd-title-row"><div><h2>Danh sách màn hình và phân quyền</h2><p>Quyền truy cập và thao tác hiện được triển khai trên website Giặt Sấy 247.</p></div><a className="erd-public-link" href="/permissions.html" target="_blank" rel="noreferrer">Mở bảng công khai ↗</a></div>
    <iframe className="permissions-frame" title="Danh sách màn hình và phân quyền Giặt Sấy 247" src="/permissions.html?embed=1" />
  </section>;
}
function Revenue({ orders, revenue, waiting, services, setServices, canEdit }) { const [draft, setDraft] = useState(null); const [newService, setNewService] = useState({ name: '', unit: 'Kg', price: 0 }); const saveService = () => { if (!draft.name.trim()) return alert('Tên dịch vụ không được để trống!'); setServices(services.map(item => item.id === draft.id ? { ...item, ...draft, name: draft.name.trim(), price: Number(draft.price) } : item)); setDraft(null); }; const addService = () => { if (!newService.name.trim() || Number(newService.price) < 0) return alert('Vui lòng nhập đủ tên và giá dịch vụ!'); setServices([...services, { ...newService, id: `srv_${Date.now()}`, name: newService.name.trim(), price: Number(newService.price), desc: `Tính theo ${newService.unit}` }]); setNewService({ name: '', unit: 'Kg', price: 0 }); }; return <section className="stack"><div><h2>Báo cáo doanh thu & đơn hàng</h2><p>Doanh thu được chia theo phương thức tiền mặt và mã QR.</p></div><div className="stats"><Stat label="Doanh thu thực thu" value={money(revenue)} hint="Từ đơn đã thanh toán" icon={<DollarSign />} color="green" /><Stat label="Tiền mặt" value={money(orders.filter(o => o.paymentMethod === 'tien_mat' && o.paymentStatus === 'da_thanh_toan').reduce((s, o) => s + o.totalAmount, 0))} hint="Đã thu tiền mặt" icon={<DollarSign />} color="blue" /><Stat label="Mã QR" value={money(orders.filter(o => o.paymentMethod === 'qr_code' && o.paymentStatus === 'da_thanh_toan').reduce((s, o) => s + o.totalAmount, 0))} hint="Đã thu qua QR" icon={<TrendingUp />} color="indigo" /><Stat label="Doanh thu chờ thu" value={money(waiting)} hint="Trả sau chưa thu" icon={<Clock />} color="amber" /></div><div className="panel"><h3>Quản lý tên dịch vụ và bảng giá {canEdit && <small className="owner-note">· Chủ tiệm có thể thêm, sửa, xóa</small>}</h3><div className="service-grid">{services.map(item => <div className="service-card" key={item.id}><b>{item.name}</b><strong>{money(item.price)} / {item.unit}</strong><small>{item.desc}</small>{canEdit && <div className="service-actions"><button onClick={() => setDraft(item)}><Pencil size={13} /> Sửa</button><button onClick={() => window.confirm(`Xóa dịch vụ ${item.name}?`) && setServices(services.filter(service => service.id !== item.id))}><Trash2 size={13} /> Xóa</button></div>}</div>)}</div>{canEdit && <div className="inline-form"><input placeholder="Tên dịch vụ mới" value={newService.name} onChange={e => setNewService({ ...newService, name: e.target.value })} /><select value={newService.unit} onChange={e => setNewService({ ...newService, unit: e.target.value })}><option>Kg</option><option>Đôi</option><option>Cái</option><option>Dịch vụ</option></select><input type="number" min="0" placeholder="Giá" value={newService.price} onChange={e => setNewService({ ...newService, price: e.target.value })} /><button className="blue-button" onClick={addService}><PlusCircle size={15} /> Thêm dịch vụ</button></div>}</div>{draft && <div className="modal-backdrop"><div className="modal"><h3>Sửa tên dịch vụ</h3><label>Tên dịch vụ<input value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} /></label><label>Đơn vị<select value={draft.unit} onChange={e => setDraft({ ...draft, unit: e.target.value })}><option>Kg</option><option>Đôi</option><option>Cái</option><option>Dịch vụ</option></select></label><label>Giá<input type="number" value={draft.price} onChange={e => setDraft({ ...draft, price: e.target.value })} /></label><div className="modal-actions"><button onClick={() => setDraft(null)}>Hủy</button><button className="blue-button" onClick={saveService}>Lưu</button></div></div></div>}</section>; }
function Stat({ label, value, hint, icon, color }) { return <div className={`stat ${color}`}><div><small>{label}</small><strong>{value}</strong><span>{hint}</span></div>{icon}</div>; }
function CreateOrder({ form, setField, search, setSearch, results, searchCustomers, onSubmit, services, learningSuggestion }) { const selectedTotal = services.reduce((sum, service) => sum + (form.services[service.id]?.selected ? service.price * Number(form.services[service.id].quantity || 0) : 0), 0); const minimumReturnAt = new Date(Date.now() + 60000).toISOString().slice(0, 16); return <section className="form-page"><div className="agent-note"><b>Agent Rule-based:</b> kiểm tra SĐT, trường bắt buộc và điều kiện thông báo trước khi lưu đơn.</div><div className="panel"><h2><Search size={19} /> Tìm kiếm khách hàng cũ</h2><div className="search-input customer-search"><Search size={16} /><input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && searchCustomers()} placeholder="Mã KH, tên hoặc SĐT..." /></div><button className="blue-button full" type="button" onClick={searchCustomers}><Search size={15} /> Tra cứu khách hàng</button>{results && <div className="results"><b>Kết quả ({results.length})</b>{results.map(customer => <div className="result" key={customer.id}><span>{customer.customerCode} · {customer.name} · {customer.phone}</span><button type="button" onClick={() => { setField('name', customer.name); setField('phone', customer.phone); }}>Chọn</button></div>)}</div>}</div><form className="panel order-form" onSubmit={onSubmit}><h3>1. Thông tin khách hàng</h3><div className="two-col"><label>Tên khách hàng *<input required value={form.name} onChange={e => setField('name', e.target.value)} /></label><label>Số điện thoại *<input required type="tel" inputMode="numeric" pattern="0[35789][0-9]{8}" maxLength="10" minLength="10" value={form.phone} onChange={e => setField('phone', e.target.value.replace(/\D/g, '').slice(0, 10))} /></label></div><h3>2. Chọn dịch vụ</h3><div className="service-selection">{services.map(service => { const item = form.services[service.id] || { selected: false, quantity: 1 }; return <div className={`service-option ${item.selected ? 'chosen' : ''}`} key={service.id}><label className="service-check"><input type="checkbox" checked={item.selected} onChange={e => setField('services', { ...form.services, [service.id]: { ...item, selected: e.target.checked } })} /><span><b>{service.name}</b><small>{money(service.price)} / {service.unit}</small></span></label>{item.selected && <label>Số lượng ({service.unit})<input type="number" min={service.unit === 'Kg' ? '0.1' : '1'} step={service.unit === 'Kg' ? '0.1' : '1'} value={item.quantity} onChange={e => setField('services', { ...form.services, [service.id]: { ...item, quantity: e.target.value } })} /></label>}</div>; })}</div><div className="total-line"><span>Tổng tiền</span><b>{money(selectedTotal)}</b></div><h3>3. Thời gian trả dự kiến</h3><label>Giờ trả dự kiến *<input required type="datetime-local" min={minimumReturnAt} value={form.estimatedReturnAt} onChange={e => setField('estimatedReturnAt', e.target.value)} /></label><button type="button" className="suggest-button" onClick={() => setField('estimatedReturnAt', learningSuggestion.value)}>Dùng giờ gợi ý</button><h3>4. Hình thức thanh toán</h3><div className="pay-choice"><button type="button" className={form.paymentTiming === 'tra_truoc' ? 'chosen' : ''} onClick={() => setField('paymentTiming', 'tra_truoc')}>TRẢ TRƯỚC</button><button type="button" className={form.paymentTiming === 'tra_sau' ? 'chosen amber' : ''} onClick={() => setField('paymentTiming', 'tra_sau')}>TRẢ SAU</button></div>{form.paymentTiming === 'tra_truoc' && <div className="method"><b>Phương thức:</b><label><input type="radio" checked={form.paymentMethod === 'tien_mat'} onChange={() => setField('paymentMethod', 'tien_mat')} /> Tiền mặt</label><label><input type="radio" checked={form.paymentMethod === 'qr_code'} onChange={() => setField('paymentMethod', 'qr_code')} /> Mã QR</label></div>}<label>Ghi chú<textarea rows="2" value={form.notes} onChange={e => setField('notes', e.target.value)} /></label><button className="blue-button full"><PlusCircle size={16} /> Tạo đơn hàng</button></form></section>; }
function Orders({ orders, query, setQuery, filter, setFilter, selected, setSelected, updateStatus }) { return <section className="stack"><div className="order-toolbar"><div className="search-input"><Search size={16} /><input placeholder="Tìm mã đơn, tên khách, SĐT..." value={query} onChange={e => setQuery(e.target.value)} /></div><div className="filter-buttons">{[['all', 'Tất cả'], ['dang_xu_ly', 'Đang xử lý'], ['da_xu_ly', 'Đã xử lý'], ['da_hoan_thanh', 'Đã hoàn thành']].map(([id, label]) => <button className={filter === id ? 'selected' : ''} onClick={() => setFilter(id)} key={id}>{label}</button>)}</div></div><div className="orders-layout"><div className="panel table-panel"><b>Danh sách đơn hàng ({orders.length})</b><div className="table-scroll"><table><thead><tr><th>Mã đơn</th><th>Khách hàng</th><th>Dịch vụ</th><th>Tổng tiền</th><th>Thanh toán</th><th>Trạng thái</th></tr></thead><tbody>{orders.map(order => <tr className={selected?.id === order.id ? 'selected-row' : ''} onClick={() => setSelected(order)} key={order.id}><td className="blue-text">{order.id}</td><td><b>{order.customerName}</b><small>{order.phone}</small></td><td>{order.serviceName}</td><td><b>{money(order.totalAmount)}</b></td><td><span className={`pill ${order.paymentStatus}`}>{order.paymentStatus === 'da_thanh_toan' ? (order.paymentMethod === 'qr_code' ? 'Đã thu QR' : 'Đã thu tiền mặt') : 'Chưa thanh toán'}</span></td><td><span className={`pill ${order.status}`}>{labels[order.status]}</span></td></tr>)}</tbody></table></div></div>{selected && <OrderDetail order={selected} updateStatus={updateStatus} close={() => setSelected(null)} />}</div></section>; }
function OrderDetail({ order, updateStatus, close }) { return <aside className="panel detail"><div className="detail-head"><div><b>{order.id}</b><small>{order.createdAt}</small></div><button onClick={close}>✕ Đóng</button></div><div className="customer-box"><b>{order.customerName}</b><span>SĐT: {order.phone}</span><span>Nhân viên đặt: {order.employeeName || 'Chưa ghi nhận'}</span><span>Trả dự kiến: {formatDateTime(order.estimatedReturnAt)}</span></div><div className="order-services">{getOrderServices(order).map(item => <div key={`${item.name}-${item.unit}`}><span>{item.name} · {item.quantity} {item.unit}</span><b>{money(item.total || item.unitPrice * item.quantity)}</b></div>)}</div><strong className="blue-text">Tổng tiền: {money(order.totalAmount)}</strong><div className="detail-pay">Thanh toán: <b>{order.paymentStatus === 'da_thanh_toan' ? (order.paymentMethod === 'qr_code' ? 'Mã QR' : 'Tiền mặt') : 'Chưa thanh toán'}</b></div>{order.status === 'dang_xu_ly' && <button className="purple-button full" onClick={() => updateStatus(order.id, 'da_xu_ly')}><CheckCircle size={15} /> Đã giặt/sấy xong</button>}{order.status === 'da_xu_ly' && <button className="green-button full" onClick={() => updateStatus(order.id, 'da_hoan_thanh')}><Package size={15} /> Giao trả đồ</button>}{order.status === 'da_hoan_thanh' && <div className="complete">✓ Đơn hàng đã hoàn thành</div>}<button className="print-button full" onClick={() => printReceipt(order)}><Printer size={15} /> In biên nhận</button></aside>; }
function printReceipt(order) { const printWindow = window.open('', '_blank', 'width=500,height=700'); if (!printWindow) return alert('Trình duyệt đang chặn cửa sổ in.'); printWindow.document.write(`<html><body><h2>TIỆM GIẶT ỦI 247</h2><p>Mã đơn: ${order.id}</p><p>Khách hàng: ${order.customerName} - ${order.phone}</p><p>Nhân viên: ${order.employeeName || ''}</p><p>Trả dự kiến: ${order.estimatedReturnAt || ''}</p><p>Tổng cộng: <b>${money(order.totalAmount)}</b></p></body></html>`); printWindow.document.close(); printWindow.print(); }
function Customers({ customers, query, setQuery, onEdit, onDelete }) { return <section className="panel"><div className="customer-heading"><div><h2>Danh sách khách hàng</h2><p>Tìm kiếm bằng mã, tên hoặc số điện thoại.</p></div><div className="search-input"><Search size={16} /><input placeholder="Tìm KH, tên, SĐT..." value={query} onChange={e => setQuery(e.target.value)} /></div></div><div className="table-scroll"><table><thead><tr><th>Mã KH</th><th>Tên khách hàng</th><th>Số điện thoại</th><th>Số đơn</th><th>Thao tác</th></tr></thead><tbody>{customers.map(item => <tr key={item.id}><td className="blue-text">{item.customerCode}</td><td><b>{item.name}</b></td><td>{item.phone}</td><td>{item.totalOrders} đơn</td><td className="actions"><button className="edit-button" onClick={() => onEdit({ ...item })}>Sửa</button><button className="delete-button" onClick={() => onDelete(item)}>Xóa</button></td></tr>)}</tbody></table></div></section>; }
function CustomerModal({ customer, onSave, onDelete, onClose }) { const [form, setForm] = useState(customer); return <div className="modal-backdrop"><form className="modal" onSubmit={e => { e.preventDefault(); onSave(form); }}><div className="modal-title"><h3>Sửa thông tin khách hàng</h3><button type="button" onClick={onClose}><X size={16} /></button></div><label>Mã khách hàng<input value={form.customerCode} disabled /></label><label>Tên khách hàng<input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label><label>Số điện thoại<input required value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></label><div className="modal-actions"><button type="button" className="red-button" onClick={() => onDelete(customer)}>Xóa</button><button type="button" onClick={onClose}>Hủy</button><button className="blue-button">Lưu</button></div></form></div>; }
function SettingsPage({ user, passwords, setPasswords, message, onSubmit, onNameChange, systemSettings, onSaveSystemSettings }) { const [name, setName] = useState(user.name || user.username); const [draft, setDraft] = useState(systemSettings); return <section className="settings-page"><form className="panel" onSubmit={event => { event.preventDefault(); onNameChange(name); }}><h2><User size={18} /> Đổi tên</h2><label>Tên hiển thị<input required value={name} onChange={event => setName(event.target.value)} /></label><button className="blue-button full">Lưu tên</button></form><form className="panel" onSubmit={onSubmit}><h2><KeyRound size={18} /> Đổi mật khẩu</h2>{message && <div className={message.error ? 'error' : 'success'}>{message.error || message.success}</div>}{['old', 'next', 'confirm'].map(key => <label key={key}>{key === 'old' ? 'Mật khẩu hiện tại' : key === 'next' ? 'Mật khẩu mới' : 'Xác nhận mật khẩu mới'}<input type="password" required value={passwords[key]} onChange={e => setPasswords({ ...passwords, [key]: e.target.value })} /></label>)}<button className="blue-button full">Lưu mật khẩu</button></form><form className="panel" onSubmit={event => { event.preventDefault(); onSaveSystemSettings(draft); }}><h2><Clock size={18} /> Ngưỡng thời gian</h2><p>Đơn chưa hoàn thành sau ngưỡng này sẽ được cảnh báo trên hệ thống.</p><label>Ngưỡng xử lý (giờ)<input type="number" min="1" step="0.5" required value={draft.processingLimitHours} onChange={event => setDraft({ ...draft, processingLimitHours: event.target.value })} /></label><button className="blue-button full">Lưu cấu hình hệ thống</button></form></section>; }
function PaymentModal({ order, method, setMethod, cancel, confirm }) { return <div className="modal-backdrop"><div className="modal"><h3>Thu tiền đơn {order.id}</h3><p>Khách hàng chưa thanh toán {money(order.totalAmount)}.</p><div className="method"><label><input type="radio" checked={method === 'tien_mat'} onChange={() => setMethod('tien_mat')} /> Tiền mặt</label><label><input type="radio" checked={method === 'qr_code'} onChange={() => setMethod('qr_code')} /> Mã QR</label></div><div className="modal-actions"><button onClick={cancel}>Hủy</button><button className="green-button" onClick={confirm}>Xác nhận đã thu</button></div></div></div>; }
