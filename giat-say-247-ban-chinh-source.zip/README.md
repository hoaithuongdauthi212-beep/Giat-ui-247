# Giặt Sấy 247

## Chạy website React

```powershell
npm install
npm run dev
```

Mở địa chỉ `http://localhost:5173`.

Tài khoản demo: `admin` / `123`.

Website hiện có đăng nhập/đăng ký, báo cáo doanh thu, tạo đơn với tối đa 5 dịch vụ cùng lúc, tìm khách hàng theo tên hoặc số điện thoại, sửa/xóa khách hàng, quản lý trạng thái đơn, thanh toán trả sau, in biên nhận riêng từng đơn và cài đặt mật khẩu.
Mục **Sơ đồ ERD** hiển thị tổng quan khách hàng, đơn hàng, dịch vụ và mối quan hệ giữa chúng.
Trang ERD công khai, không cần đăng nhập: `/erd.html` (ví dụ `https://ten-mien-cua-ban/erd.html` sau khi triển khai website).

Khi vào hệ thống cần chọn vai trò trước. Tài khoản demo **chủ tiệm** là `admin / 123`; tài khoản demo **nhân viên** là `nhanvien / 456`. Chủ tiệm có quyền sửa bảng giá, nhân viên chỉ được sử dụng các nghiệp vụ đơn hàng và không được sửa giá.

MVP dashboard quản lý quy trình giặt sấy: tiếp nhận đơn, giặt, sấy, kiểm soát công suất và theo dõi hoạt động.

## Chạy dự án

Mở trực tiếp `index.html` bằng trình duyệt để xem giao diện website. Dự án không cần cài Node.js cho phần giao diện.

Các đơn mới được lưu bằng `localStorage`. Khi cấu hình Supabase, dữ liệu dịch vụ, khách hàng và đơn hàng được đồng bộ lâu dài qua REST API; `localStorage` vẫn là fallback khi chưa có cấu hình.

## Kết nối Supabase

1. Tạo project Supabase và chạy [supabase-schema.sql](./supabase-schema.sql) trong SQL Editor.
2. Tạo file `.env.local`:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_ANON_KEY
VITE_SMS_WEBHOOK_URL=
```

`VITE_SMS_WEBHOOK_URL` là webhook dịch vụ SMS bên ngoài (không bắt buộc). Nếu bỏ trống, thao tác duyệt tin nhắn chỉ mô phỏng việc gửi để demo.

## Các phần đã có

- Dashboard KPI trong ngày.
- Kanban theo 4 công đoạn: mới tiếp nhận, đang giặt, đang sấy, sẵn sàng giao.
- Tạo đơn mới bằng biểu mẫu.
- Theo dõi hoạt động gần đây và công suất thiết bị.
- Giao diện responsive cho màn hình nhỏ.

## Hướng mở rộng

Kết nối API và cơ sở dữ liệu để lưu đơn hàng thật, thêm phân quyền nhân viên, in phiếu nhận đồ, quản lý nhiều chi nhánh và báo cáo doanh thu.
