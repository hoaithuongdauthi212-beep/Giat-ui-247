create table if not exists services (
  id text primary key,
  name text not null,
  unit text not null,
  price numeric not null default 0,
  desc text
);

create table if not exists customers (
  id text primary key,
  customerCode text not null,
  name text not null,
  phone text not null,
  totalOrders integer not null default 0
);

create table if not exists orders (
  id text primary key,
  customerId text,
  customerCode text,
  customerName text not null,
  phone text not null,
  services jsonb,
  serviceName text,
  quantity numeric,
  unit text,
  unitPrice numeric,
  totalAmount numeric not null default 0,
  paymentTiming text,
  paymentMethod text,
  paymentStatus text,
  status text,
  createdAt text,
  createdAtISO timestamptz,
  estimatedReturnAt text,
  suggestionText text,
  employeeName text,
  actualProcessingMinutes integer,
  notes text
);

alter table services enable row level security;
alter table customers enable row level security;
alter table orders enable row level security;

create policy "anon can read and write services" on services for all to anon using (true) with check (true);
create policy "anon can read and write customers" on customers for all to anon using (true) with check (true);
create policy "anon can read and write orders" on orders for all to anon using (true) with check (true);
